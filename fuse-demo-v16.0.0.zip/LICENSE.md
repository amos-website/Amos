Envato Standard License

Copyright (c) Sercan Yemen <sercanyemen@gmail.com>

This project is protected by Envato's Standard License. For more information,
check the official license page at [https://themeforest.net/licenses/standard](https://themeforest.net/licenses/standard)
