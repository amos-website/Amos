import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('16.0.0').full;
