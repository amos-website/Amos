import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector     : 'mailbox-empty-details',
    templateUrl  : './empty-details.component.html',
    encapsulation: ViewEncapsulation.None
})
export class MailboxEmptyDetailsComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
